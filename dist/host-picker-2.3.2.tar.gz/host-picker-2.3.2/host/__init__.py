# Initialize the Higher Order STatistics picker

__author__ = "Matteo Bagagli"
__date__ = "10/2020"
__version__ = "2.3.2"
